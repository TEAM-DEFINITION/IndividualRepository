package com.example.hybrid_access_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
