import 'package:flutter/material.dart';
import 'package:hybrid_access_app/login_page.dart';
import 'tab_page.dart';
import 'login_page.dart';

class RootPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return LoginPage();
  }
}